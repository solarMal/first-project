public class MonthData {
    int days[] = new int[30];//массив days это дни в месяце

}
