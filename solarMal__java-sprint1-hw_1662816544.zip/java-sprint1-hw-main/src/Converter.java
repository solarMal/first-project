public class Converter {
    double step = 1.0;


    public double traveledDistanceConverter(double step){
//        if (step > 0) {
            double distance = 75.0;
            double kilometer = (distance * step) / 100000;

//            System.out.println("вы прошли дистанцию " + kilometer + " километра(ов)");
//        }else {
//            System.out.println("введите положительное число");
//        }
        return kilometer;
    }

    public double burnedCalories(int step){
//        if (step > 0) {
            int calories = step * 50;

            double kilocalorie = calories / 1000.0;

//            System.out.println("вы сожгли за " + step + " шага(ов) " + calories +
//                    " калорий и " + kilocalorie + " килокалорий");
//        }else {
//            System.out.println("введите положительное число");
//        }
        return kilocalorie;
    }

}
