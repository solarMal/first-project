import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Converter converter = new Converter();
        StepTracker stepTracker = new StepTracker();

        Scanner scanner = new Scanner(System.in);
        System.out.println("Выберите один из пунктов:");
        while (true) {
            int month;
            int day;
            int step;
            printMenu();
            int command = scanner.nextInt();

            if (command == 1) {
                System.out.println("Выберите месяц: 0. Январь, 1. Февраль, 2. Март, 3. Апрель, 4 Май, 5 Июнь," +
                        "6. Июль, 7. Август, 8. Сентябрь, 9. Октябрь, 10. Ноябрь, 11. Декабрь");
                month = scanner.nextInt();
                System.out.println("Выберите номер дня от 0-29");
                day = scanner.nextInt();
                System.out.println("введите колличество шагов пройденых в этот день");
                step = scanner.nextInt();
                stepTracker.stepsOfDays(stepTracker.monthToData[month], day, step);
            } else if (command == 2) {
                System.out.println("Выберите месяц: 0. Январь, 1. Февраль, 2. Март, 3. Апрель, 4 Май, 5 Июнь," +
                        "6. Июль, 7. Август, 8. Сентябрь, 9. Октябрь, 10. Ноябрь, 11. Декабрь");
                month = scanner.nextInt();

                System.out.println("Количество пройденных шагов по дням:");
                stepTracker.numberOfStepsTakenPerDay(stepTracker.monthToData[month]);
                System.out.println();

                System.out.println("общее колличество шагов за месяц "
                        + stepTracker.stepPerMonth(stepTracker.monthToData[month]));

                System.out.println("максимально пройденое колличество шагов в месяце " +
                        stepTracker.maximumNumberOfStepsTakenPerMonth(stepTracker.monthToData[month]));

                System.out.println("Среднее колличество шагов за месяц "
                        + stepTracker.averageNumberOfSteps(stepTracker.monthToData[month]));

                System.out.println("пройденная дистанция в киллометрах " +
                        converter.traveledDistanceConverter(stepTracker.stepPerMonth(stepTracker.monthToData[month])) +
                        " километров за месяц");

                System.out.println("колличество сожжённых килокалорий "
                        + converter.burnedCalories(stepTracker.stepPerMonth(stepTracker.monthToData[month])) + " килокалорий");

                System.out.println("колличество дней когда вы прошли больше шагов, чем целевое значение " +
                        stepTracker.maximumNumberOfConsecutiveDays(stepTracker.monthToData[month]) + " дня");
            } else if (command == 3) {
                int setSteps = scanner.nextInt();
                stepTracker.setTargetNumberOfSteps(setSteps);
            } else if (command == 0) {
                return;
            } else {
                System.out.println("выберите действие из списка меню:");
            }
        }
    }

    private static void printMenu() {
        System.out.println("1. Ввести количество шагов за определённый день");
        System.out.println("2. Напечатать статистику за определённый месяц");
        System.out.println("3. Изменить цель по количеству шагов в день");
        System.out.println("0. Выйти из приложения");
    }
}
